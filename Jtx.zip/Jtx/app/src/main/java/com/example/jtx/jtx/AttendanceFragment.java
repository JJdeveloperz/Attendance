package com.example.jtx.jtx;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.method.ScrollingMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.safety.Whitelist;

import java.io.IOException;

public class AttendanceFragment extends Fragment {

    TextView txt;
    Button btn;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.attendancefragment,null);
    }




    @Override
    public void onViewCreated(@NonNull final View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        view.findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                {
                    txt=view.findViewById(R.id.textView);

                    txt.setMovementMethod(new ScrollingMovementMethod());
                    btn = view.findViewById(R.id.button);
                    final StringBuilder builder = new StringBuilder();
                    new Thread(new Runnable() {
                        @Override
                        public void run() {

                            try {
                                Document doc = Jsoup.connect("https://jjdeveloperz.github.io/Attendance/").get();
                                doc.outputSettings(new Document.OutputSettings().prettyPrint(false));
                                doc.select("br").after("\\n");
                                doc.select("p").after("\\n");
                                doc.select("p").before("\\n");
                                String st=doc.html().replaceAll("\\\\n","\n");
                                String str=Jsoup.clean(st,"",Whitelist.none(),new Document.OutputSettings().prettyPrint(false));
                                builder.append(str);


                            } catch (IOException e) {
                                builder.append("Error:").append(e.getMessage());

                            }

                            AttendanceFragment.this.getActivity().runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    txt.setText(builder.toString());
                                }
                            });
                        }


                    }).start();
                }
            }
        });
    }

}


package com.example.jtx.jtx;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;





public class sgpa extends Fragment {


    EditText rdbms_int, rdbms_ext, cg_int, cg_ext, daa_int, daa_ext, wt_int, wt_ext, elective_int, elective_ext, rdbms_lab_int, rdbms_lab_ext, cg_lab_int, cg_lab_ext, wt_lab_int, wt_lab_ext, daa_lab_int, daa_lab_ext, traini_int, traini_ext;
    Double theory, lab, total;
    Double rdbms_intm = 0.0, rdbms_extm = 0.0, cg_intm = 0.0, cg_extm = 0.0, daa_intm = 0.0, daa_extm = 0.0, wt_intm = 0.0, wt_extm = 0.0, elective_intm = 0.0, elective_extm = 0.0, rdbms_lab_intm = 0.0, rdbms_lab_extm = 0.0, cg_lab_intm = 0.0, cg_lab_extm = 0.0, wt_lab_intm = 0.0, wt_lab_extm = 0.0, daa_lab_intm = 0.0, daa_lab_extm = 0.0, traini_intm = 0.0, traini_extm = 0.0;
    Double r;
    String result;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.sgpaactivity, null);
    }


    @Override
    public void onViewCreated(@NonNull final View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        view.findViewById(R.id.btn_calculate).setOnClickListener(new View.OnClickListener()
{
@Override public void onClick(View v) {

                                                                         try {
                                                                             rdbms_int = view.findViewById(R.id.rdbms_int);
                                                                             rdbms_ext = view.findViewById(R.id.rdbms_ext);
                                                                             cg_int = view.findViewById(R.id.cg_int);
                                                                             cg_ext = view.findViewById(R.id.cg_ext);
                                                                             daa_int = view.findViewById(R.id.daa_int);
                                                                             daa_ext = view.findViewById(R.id.daa_ext);
                                                                             wt_int = view.findViewById(R.id.wt_int);
                                                                             wt_ext = view.findViewById(R.id.wt_ext);
                                                                             elective_int = view.findViewById(R.id.elective_int);
                                                                             elective_ext = view.findViewById(R.id.elective_ext);
                                                                             rdbms_lab_int = view.findViewById(R.id.rdbms_lab_int);
                                                                             rdbms_lab_ext = view.findViewById(R.id.rdbms_lab_ext);
                                                                             cg_lab_int = view.findViewById(R.id.cg_lab_int);
                                                                             cg_lab_ext = view.findViewById(R.id.cg_lab_ext);
                                                                             wt_lab_int = view.findViewById(R.id.wt_lab_int);
                                                                             wt_lab_ext = view.findViewById(R.id.wt_lab_ext);
                                                                             daa_lab_int = view.findViewById(R.id.daa_lab_int);
                                                                             daa_lab_ext = view.findViewById(R.id.daa_lab_ext);
                                                                             traini_int = view.findViewById(R.id.trainee_int);
                                                                             traini_ext = view.findViewById(R.id.trainee_ext);

                                                                             rdbms_intm = Double.parseDouble(rdbms_int.getText().toString());
                                                                             rdbms_extm = Double.parseDouble(rdbms_ext.getText().toString());
                                                                             cg_intm = Double.parseDouble(cg_int.getText().toString());
                                                                             cg_extm = Double.parseDouble(cg_ext.getText().toString());
                                                                             daa_intm = Double.parseDouble(daa_int.getText().toString());
                                                                             daa_extm = Double.parseDouble(daa_ext.getText().toString());
                                                                             wt_intm = Double.parseDouble(wt_int.getText().toString());
                                                                             wt_extm = Double.parseDouble(wt_ext.getText().toString());
                                                                             elective_intm = Double.parseDouble(elective_int.getText().toString());
                                                                             elective_extm = Double.parseDouble(elective_ext.getText().toString());
                                                                             rdbms_lab_intm = Double.parseDouble(rdbms_lab_int.getText().toString());
                                                                             rdbms_lab_extm = Double.parseDouble(rdbms_lab_ext.getText().toString());
                                                                             cg_lab_intm = Double.parseDouble(cg_lab_int.getText().toString());
                                                                             cg_lab_extm = Double.parseDouble(cg_lab_ext.getText().toString());
                                                                             wt_lab_intm = Double.parseDouble(wt_lab_int.getText().toString());
                                                                             wt_lab_extm = Double.parseDouble(wt_lab_ext.getText().toString());
                                                                             daa_lab_intm = Double.parseDouble(daa_lab_int.getText().toString());
                                                                             daa_lab_extm = Double.parseDouble(daa_lab_ext.getText().toString());
                                                                             traini_intm = Double.parseDouble(traini_int.getText().toString());
                                                                             traini_extm = Double.parseDouble(traini_ext.getText().toString());
                                                                             theory = ((convert(rdbms_intm + rdbms_extm) + convert(cg_intm + cg_extm) + convert(daa_intm + daa_extm) + convert(wt_intm + wt_extm) + convert(elective_intm + elective_extm)) * 4);
                                                                             lab = (double) ((convert((rdbms_lab_intm + rdbms_lab_extm) * 2) + convert((wt_lab_intm + wt_lab_extm) * 2) + convert(traini_intm + traini_extm)) * 2 + (convert((cg_lab_intm + cg_lab_extm) * 2) + convert((daa_lab_intm + daa_lab_extm) * 2)));

                                                                             total = ((theory + lab) / 28);
                                                                             Toast.makeText(getActivity(), "Your SGPA=" + total.toString(), Toast.LENGTH_LONG).show();
                                                                             



                                                                         } catch (Exception e) {

                                                                             Toast.makeText(getActivity(),e.getMessage(), Toast.LENGTH_LONG).show();

                                                                         }
                                                                     }

                                                                     public Double convert(Double a) {
                                                                         if (a >= 90) {
                                                                             r = Double.valueOf(10);
                                                                         } else if (a >= 80 && a < 90)
                                                                             r = Double.valueOf(9);
                                                                         else if (a >= 70 && a < 80)
                                                                             r = Double.valueOf(8);
                                                                         else if (a >= 60 && a < 70)
                                                                             r = Double.valueOf(7);
                                                                         else if (a >= 50 && a < 60)
                                                                             r = Double.valueOf(6);
                                                                         else if (a >= 40 && a < 50)
                                                                             r = Double.valueOf(5);
                                                                         else if (a >= 30 && a < 40)
                                                                             r = Double.valueOf(4);
                                                                         return r;
                                                                     }
                                                                 }
        );
    }
}


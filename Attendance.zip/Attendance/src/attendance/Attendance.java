package attendance;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.phantomjs.PhantomJSDriver;

import java.io.FileWriter;
import java.util.List;

public class Attendance extends javax.swing.JFrame {
    
       int count=0;
    String arr[]=new String[15];
    
    
    WebDriver driver = new FirefoxDriver();
     
    String atten="";        
    String file = "/home/jtx/Desktop/index.html";
    public Attendance() {
        initComponents();

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        tpass = new javax.swing.JPasswordField();
        jLabel4 = new javax.swing.JLabel();
        tid = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 0, 51));

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Enter Username");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(63, 98, 137, -1));

        jButton1.setBackground(new java.awt.Color(255, 0, 0));
        jButton1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Submit");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 350, -1, -1));

        jLabel3.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("LOGIN");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 20, -1, -1));
        jPanel2.add(tpass, new org.netbeans.lib.awtextra.AbsoluteConstraints(312, 172, 150, 36));

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Enter Password");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(63, 172, 137, 36));

        tid.setCaretColor(new java.awt.Color(255, 0, 0));
        tid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tidActionPerformed(evt);
            }
        });
        jPanel2.add(tid, new org.netbeans.lib.awtextra.AbsoluteConstraints(312, 92, 150, 36));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(493, 493, 493)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 578, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 465, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
 String id=tid.getText();
        String pass=tpass.getText();       
        try
             {
                 driver.get("https://academics.gndec.ac.in");            
                 driver.findElement(By.id("username")).sendKeys(id);
                 driver.findElement(By.id("password")).sendKeys(pass);
                 driver.findElement(By.name("submit")).click();
                 this.hide();
                 driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div/div[2]/form/button")).click();
                 List<WebElement> rows = driver.findElements(By.xpath("/html/body/form/table/tbody/tr"));

                 String p[] = new String[rows.size() + 1];
                 int pheld[] = new int[rows.size() + 1];
                 int pattende[] = new int[rows.size() + 1];
                 Double ppercent[] = new Double[rows.size() + 1];
                 for (int i = 1; i <= rows.size(); i++)
                 {
                      count = 0;
                     p[i] = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[" + i + "]/td[2]")).getText();
                     pheld[i] = Integer.parseInt(driver.findElement(By.xpath("/html/body/form/table/tbody/tr[" + i + "]/td[4]")).getText());
                     pattende[i] = Integer.parseInt(driver.findElement(By.xpath("/html/body/form/table/tbody/tr[" + i + "]/td[5]")).getText());
                     ppercent[i] = Double.valueOf((driver.findElement(By.xpath("/html/body/form/table/tbody/tr[" + i + "]/td[6]")).getText()));

                     if (ppercent[i] < 75.0)
                     {
                         lecreq(pattende[i], pheld[i]);
                     }

                     arr[i]=" Subject name=" + p[i] + "<br> Lectures held=" + pheld[i] + " <br>  Lectures Attended=" + pattende[i] + " <br>  Percentage=" + ppercent[i] + " <br>  Lectures needed=" + count + "<br><br><br>";
               


                 }
                 for(int i=1;i<=rows.size();i++)
                 {
                    atten =  atten+"<br>"+arr[i];

                 }
                    FileWriter fw = new FileWriter(file);
                 fw.write("<html><head> </head>  <body> <p id='att'>"+atten+"</p> </body> </html>");
                         fw.close();
                        
                 driver.get("https://github.com/login");
                 driver.findElement(By.xpath("//*[@id=\"login_field\"]")).sendKeys("jjdeveloperz@gmail.com");
                 driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys("1606728Jj");
                 driver.findElement(By.xpath("/html/body/div[3]/div[1]/div/form/div[3]/input[3]")).click();
                 driver.get("https://github.com/JJdeveloperz/Attendance/upload/master");


                 driver.findElement(By.xpath("/html/body/div[4]/div/div/div[2]/div[1]/div[2]/form[2]/div/p/input")).sendKeys(file);
                 try {
                     Thread.sleep(10000);
                 } catch (InterruptedException e) {
                     e.printStackTrace();
                 }
                 driver.findElement(By.xpath("/html/body/div[4]/div/div/div[2]/div[1]/form/button")).click();
                 try {
                     Thread.sleep(60000);
                     driver.get("https://jjdeveloperz.github.io/Attendance/");
                 } catch (InterruptedException e) {
                     e.printStackTrace();
                 }




             }
                 catch(Exception e)
                 {
                 }




                

// TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void tidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tidActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tidActionPerformed

      public void lecreq(int m,int n)
        {
            if((m*100/n)<75.0)
            {
                m++;
                n++;
                count++;
                lecreq(m,n);
            }
        }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Attendance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Attendance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Attendance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Attendance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Attendance().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JTextField tid;
    private javax.swing.JPasswordField tpass;
    // End of variables declaration//GEN-END:variables
}
